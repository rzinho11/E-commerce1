const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database'); // Ajuste o caminho para o arquivo de configuração do Sequelize

// Definindo o modelo Produto
const Produto = sequelize.define('Produto', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true,
    allowNull: false
  },
  nome: {
    type: DataTypes.STRING,
    allowNull: false,
    validate: {
      notEmpty: {
        msg: "O nome do produto não pode ser vazio"
      }
    }
  },
  descricao: {
    type: DataTypes.TEXT,
    allowNull: true
  },
  preco: {
    type: DataTypes.DECIMAL(10, 2),
    allowNull: false,
    validate: {
      isDecimal: {
        msg: "O preço deve ser um número decimal válido"
      },
      min: 0.01 // O preço não pode ser menor que 0.01
    }
  },
  quantidade_estoque: {
    type: DataTypes.INTEGER,
    allowNull: false,
    defaultValue: 0,
    validate: {
      isInt: {
        msg: "A quantidade em estoque deve ser um número inteiro"
      },
      min: 0 // A quantidade não pode ser negativa
    }
  },
  categoria_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: 'Categorias', // Supondo que existe uma tabela 'Categorias'
      key: 'id'
    }
  }
}, {
  // Opções adicionais
  tableName: 'produtos', // Nome da tabela no banco
  timestamps: true, // Adiciona campos 'createdAt' e 'updatedAt'
  paranoid: true, // Habilita soft delete (exclui registros de forma 'soft')
  underscored: true // Convenção de nomes com underscore (snake_case)
});

// Relacionamento com o modelo de Categoria
Produto.associate = (models) => {
  Produto.belongsTo(models.Categoria, {
    foreignKey: 'categoria_id',
    as: 'categoria' // Nome do relacionamento
  });
};

module.exports = Produto;