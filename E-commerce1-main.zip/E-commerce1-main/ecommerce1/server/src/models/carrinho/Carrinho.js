const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database');
const Produto = require('../produto/Produto');

const Carrinho = sequelize.define('Carrinho', {
  usuario_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: 'Cliente',
      key: 'id',
    },
  },
  ativo: {
    type: DataTypes.BOOLEAN,
    defaultValue: true,
  },
}, {
  tableName: 'carrinho',
});

// Definindo a relação many-to-many entre Carrinho e Produto
Carrinho.associate = models => {
  Carrinho.belongsTo(models.Cliente, {
    foreignKey: 'usuario_id',
    as: 'cliente',
  });
  
  Carrinho.belongsToMany(models.Produto, {
    through: 'CarrinhoProduto', // Nome da tabela intermediária
    foreignKey: 'carrinho_id',
    otherKey: 'produto_id',
    as: 'produtos',
  });
};

// Método para atualizar a quantidade de um produto no carrinho
Carrinho.prototype.updateProdutoQuantidade = async function (produtoId, quantidade) {
  const produtoNoCarrinho = await this.getProdutos({ where: { id: produtoId } });

  if (produtoNoCarrinho.length > 0) {
    // Atualiza a quantidade do produto no carrinho
    await this.addProduto(produtoId, { through: { quantidade } });
  }
};

// Método para limpar o carrinho
Carrinho.prototype.clearCarrinho = async function () {
  await this.setProdutos([]); // Remove todos os produtos do carrinho
};

module.exports = Carrinho;