class ContatoController {

    // Enviar mensagem de contato
    async enviarMensagem(req, res) {
      const { nome, email, mensagem } = req.body;
  
      try {
        console.log('Dados recebidos:', req.body);
  
        // Validação dos campos
        if (!nome || !email || !mensagem) {
          return res.status(400).json({ error: 'Todos os campos são obrigatórios.' });
        }
  
        // Retorno de sucesso
        res.status(200).json({ message: 'Mensagem enviada com sucesso!' });
      } catch (error) {
        console.error('Erro ao enviar a mensagem:', error);
        res.status(500).json({ error: 'Erro ao enviar a mensagem', descricao: error.message });
      }
    }
  }
  
  module.exports = new ContatoController();
  